import configparser

#ConfigParserオブジェクトを生成
config = configparser.ConfigParser()
#設定ファイル読み込み
config.read('setting.ini')
